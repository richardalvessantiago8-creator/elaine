package com.elaine.ai;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
